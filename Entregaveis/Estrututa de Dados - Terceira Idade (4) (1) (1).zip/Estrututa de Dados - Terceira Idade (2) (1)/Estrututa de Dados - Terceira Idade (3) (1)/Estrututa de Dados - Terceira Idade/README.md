# Citizen Assist AI – Gerenciador de Orientações (DSA)

**Disciplina:** Data Structures and Algorithms · **Linguagem:** Python 3.8+ · **Dependências:** nenhuma (apenas biblioteca padrão)

## Integrantes do Grupo
* **Pedro Henrique Neves** — RM: 571382
* **Akin Alexandre Mendes Martins** — RM: 572773
* **Maria Eduarda Rocha Benjamim** — RM: 570554

## 1. Objetivo
O Citizen Assist AI é um protótipo acadêmico que busca facilitar o acesso de pessoas idosas a informações úteis do dia a dia. O público também pode incluir pessoas com pouca familiaridade com tecnologia ou dificuldade para compreender textos técnicos.

Por isso, a interface usa frases curtas e opções simples. O sistema oferece orientações sobre golpes e segurança, serviços públicos, saúde e bancos e pagamentos. O conteúdo deve ser conferido pela equipe antes de qualquer uso fora da atividade acadêmica. O protótipo não é um canal oficial e não substitui atendimento profissional ou de órgãos públicos.

## 2. Como executar
```bash
python gerenciador_orientacoes.py   # abre o sistema
python testes.py                    # executa os testes
```
Os três arquivos (`gerenciador_orientacoes.py`, `orientacoes.csv` e `testes.py`) devem ficar na mesma pasta. A base CSV é carregada quando o programa é iniciado.

## 3. Como o usuário utiliza o sistema
No menu inicial, a pessoa pode:
1. Escolher um assunto, como golpes, serviços públicos, saúde ou bancos e pagamentos.
2. Procurar uma orientação digitando uma palavra simples, como “Pix”, “vacina” ou “aposentadoria”.
3. Ver todas as orientações disponíveis.
4. Sair do sistema.

As opções de cadastro, consulta por número, atualização, exclusão, ordenação e análise ficam em um menu separado, identificado como **opções de organização da equipe**. Isso mantém os recursos necessários para demonstrar os requisitos de DSA sem deixar o menu principal carregado de funções técnicas.

## 4. Modelo do registro (`Orientacao`)
| Campo | Descrição |
|---|---|
| id | Número único do registro |
| categoria | Assunto ao qual a orientação pertence |
| palavras_chave | Palavras que ajudam a encontrar a orientação, separadas por `;` |
| titulo | Título curto e direto |
| orientacao | Explicação em linguagem cotidiana |
| fonte | Fonte indicada para a informação |
| atualizado_em | Mês/ano registrado no conteúdo |

## 5. Estrutura de dados
Lista encadeada simples, implementada pelas classes `No` e `ListaEncadeada`.
```
inicio -> [No: dado | proximo] -> [No: dado | proximo] -> ... -> [No | None] <- fim
```
- `No.dado` guarda um objeto `Orientacao`; `No.proximo` aponta para o próximo nó.
- A lista mantém `inicio`, `fim` e `tamanho`. O ponteiro `fim` permite inserir no final em O(1).
- A remoção ajusta os ponteiros e mantém o tamanho correto.
- A lista encadeada é a estrutura usada para armazenar os registros; o Merge Sort também reorganiza os nós sem usar `sort()` ou `sorted()`.

## 6. Algoritmos
**Busca por número (ID):** percorre a lista nó por nó até encontrar o registro. Se não encontrar, devolve `None`.

**Pesquisa por palavra:** transforma o texto em minúsculas e remove acentos para facilitar a busca. A pesquisa percorre os registros e verifica se os termos digitados aparecem nos campos de texto.

**Ordenação (Merge Sort próprio):** divide a lista em duas partes, ordena cada parte e depois junta os resultados na ordem escolhida. O algoritmo religa os nós e tem custo O(n log n).

## 7. Análise Big-O
*n = quantidade de registros; m = tamanho médio do texto analisado.*

| Operação | Melhor caso | Pior caso | Justificativa |
|---|---|---|---|
| Inserir no início | O(1) | O(1) | Ajusta o ponteiro `inicio` |
| Inserir no fim | O(1) | O(1) | Usa o ponteiro `fim` |
| Percorrer/listar | O(n) | O(n) | Visita todos os nós |
| Buscar por ID | O(1) | O(n) | Pode encontrar no primeiro nó ou percorrer tudo |
| Pesquisar por texto | O(n·m) | O(n·m) | Analisa os textos dos registros |
| Atualizar | O(1) | O(n) | Depende da busca pelo ID |
| Remover por ID | O(1) | O(n) | Depende da busca pelo ID |
| Merge Sort | O(n log n) | O(n log n) | Divide e intercala os nós |
| Contar por categoria | O(n) | O(n) | Faz um percurso pela lista |
| Cadastrar com ID único | O(n) | O(n) | Verifica se o ID já existe |

**Espaço:** a lista ocupa O(n). O Merge Sort utiliza O(log n) de pilha de recursão e religa os nós sem criar cópias dos registros.

## 8. Validações e cuidados
O sistema verifica entradas numéricas, opções inexistentes, campos obrigatórios, IDs repetidos e consultas sem resultado. Também evita cadastrar textos que pareçam conter CPF ou e-mail. Telefones de serviços oficiais podem aparecer nas orientações.

As informações do CSV foram redigidas com frases curtas e linguagem cotidiana para facilitar a leitura pelo público idoso, mantendo as fontes oficiais de referência (Banco Central do Brasil, Procon e gov.br) e a data de registro de cada orientação.


## 9. Testes e Evidências
* **Testes Automatizados (`testes.py`):** Execute `python testes.py` para validar lista vazia, inserção, percurso, busca, ordenação, atualização, remoção, análise, validações e leitura/gravação do CSV (50/50 testes aprovados, com saída salva no repositório).
* **Evidências Visuais (`evidencias/`):** A pasta contém 8 capturas de tela do terminal demonstrando o uso interativo do sistema na prática (menu principal, consultas, pesquisa por palavra, CRUD administrativo, ordenação e resumo por categoria).
* **Vídeo de Demonstração:** https://youtube.com/shorts/-3FExAfPSwA?feature=share


## 10. Roteiro curto para demonstração
1. Abrir o programa e escolher “Quero ajuda com um assunto”.
2. Selecionar “Golpes e segurança” e mostrar uma orientação em linguagem simples.
3. Voltar ao menu e procurar “Pix” por palavra.
4. Mostrar todas as orientações.
5. Entrar nas opções de organização da equipe e demonstrar cadastro, consulta, atualização e exclusão.
6. Demonstrar a ordenação e o resumo por categoria.
7. Executar `python testes.py`.
8. No código, mostrar `No`, `ListaEncadeada`, a busca sequencial e `_merge_sort`, explicando a análise Big-O.
