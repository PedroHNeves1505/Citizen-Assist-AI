"""
Citizen Assist AI - Gerenciador de Orientacoes (Data Structures and Algorithms)
Recorte: orientacoes digitais para a terceira idade (golpes, servicos publicos,
saude e bancos digitais).

Estrutura principal: lista encadeada simples implementada pela equipe
(classes No e ListaEncadeada). Nenhuma list/sort pronta e usada para armazenar
ou ordenar os registros.

"""

import csv
import os
import re
import unicodedata
from dataclasses import dataclass
from datetime import date

PASTA = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_CSV = os.path.join(PASTA, "orientacoes.csv")
CAMPOS = ["id", "categoria", "palavras_chave", "titulo",
          "orientacao", "fonte", "atualizado_em"]


# ----------------------------------------------------------------------
# Modelo do registro
# ----------------------------------------------------------------------
@dataclass
class Orientacao:
    id: int
    categoria: str
    palavras_chave: str
    titulo: str
    orientacao: str
    fonte: str
    atualizado_em: str


def normalizar(texto):
    texto = unicodedata.normalize("NFD", str(texto).lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


# ----------------------------------------------------------------------
# Lista encadeada
# ----------------------------------------------------------------------
class No:
    def __init__(self, dado):
        self.dado = dado
        self.proximo = None


class ListaEncadeada:
    """Lista encadeada simples com ponteiros para inicio e fim."""

    def __init__(self):
        self.inicio = None
        self.fim = None
        self.tamanho = 0

    def __len__(self):
        return self.tamanho

    def esta_vazia(self):
        return self.inicio is None

    def __iter__(self):
        atual = self.inicio
        while atual is not None:
            yield atual.dado
            atual = atual.proximo

    # ---- insercao ----
    def inserir_inicio(self, dado):
        """O(1)."""
        novo = No(dado)
        novo.proximo = self.inicio
        self.inicio = novo
        if self.fim is None:
            self.fim = novo
        self.tamanho += 1

    def inserir_fim(self, dado):
        """O(1)"""
        novo = No(dado)
        if self.fim is None:
            self.inicio = novo
        else:
            self.fim.proximo = novo
        self.fim = novo
        self.tamanho += 1

    # ---- busca ----
    def buscar_por_id(self, id_):
        for dado in self:
            if dado.id == id_:
                return dado
        return None

    def pesquisar(self, texto, campo=None):
        """
        Busca sequencial por termos. Todos os termos digitados precisam
        aparecer (E). Se 'campo' for informado (ex.: 'categoria'), busca so nele;
        senao busca em titulo, categoria, palavras-chave e orientacao.
        Retorna uma NOVA ListaEncadeada (vazia se nada for encontrado).
        """
        termos = normalizar(texto).split()
        resultado = ListaEncadeada()
        if not termos:
            return resultado
        for dado in self:
            if campo:
                alvo = normalizar(getattr(dado, campo))
            else:
                alvo = normalizar(" ".join([dado.titulo, dado.categoria,
                                            dado.palavras_chave, dado.orientacao]))
            if all(t in alvo for t in termos):
                resultado.inserir_fim(dado)
        return resultado

    # ---- atualizacao ----
    def atualizar(self, id_, **novos_valores):
        """Atualiza campos de um registro. O(n). Retorna True se achou."""
        dado = self.buscar_por_id(id_)
        if dado is None:
            return False
        for campo, valor in novos_valores.items():
            if campo != "id" and hasattr(dado, campo):
                setattr(dado, campo, valor)
        return True

    # ---- remocao ----
    def remover_por_id(self, id_):
        """O(n). Mantem 'inicio', 'fim' e 'tamanho' consistentes."""
        anterior = None
        atual = self.inicio
        while atual is not None:
            if atual.dado.id == id_:
                if anterior is None:
                    self.inicio = atual.proximo
                else:
                    anterior.proximo = atual.proximo
                if atual is self.fim:
                    self.fim = anterior
                atual.proximo = None
                self.tamanho -= 1
                return True
            anterior = atual
            atual = atual.proximo
        return False

    # ---- ordenacao (Merge Sort proprio) ----
    def ordenar(self, chave, reverso=False):
        self.inicio = self._merge_sort(self.inicio, chave, reverso)
        self.fim = None
        atual = self.inicio
        while atual is not None:
            self.fim = atual
            atual = atual.proximo

    def _dividir(self, cabeca):
        lento = cabeca
        rapido = cabeca.proximo
        while rapido is not None and rapido.proximo is not None:
            lento = lento.proximo
            rapido = rapido.proximo.proximo
        meio = lento.proximo
        lento.proximo = None
        return meio

    def _merge_sort(self, cabeca, chave, reverso):
        if cabeca is None or cabeca.proximo is None:
            return cabeca
        meio = self._dividir(cabeca)
        esquerda = self._merge_sort(cabeca, chave, reverso)
        direita = self._merge_sort(meio, chave, reverso)
        return self._mesclar(esquerda, direita, chave, reverso)

    def _mesclar(self, a, b, chave, reverso):
        sentinela = No(None)
        cauda = sentinela
        while a is not None and b is not None:
            ka, kb = chave(a.dado), chave(b.dado)
            pegar_a = ka >= kb if reverso else ka <= kb
            if pegar_a:
                cauda.proximo, a = a, a.proximo
            else:
                cauda.proximo, b = b, b.proximo
            cauda = cauda.proximo
        cauda.proximo = a if a is not None else b
        return sentinela.proximo

    # ---- processamento ----
    def contar_por_categoria(self):
        """Dicionario categoria -> quantidade. O(n)."""
        contagem = {}
        for dado in self:
            contagem[dado.categoria] = contagem.get(dado.categoria, 0) + 1
        return contagem

    def proximo_id(self):
        """Maior id + 1. O(n)."""
        maior = 0
        for dado in self:
            if dado.id > maior:
                maior = dado.id
        return maior + 1


# ----------------------------------------------------------------------
# Persistencia em CSV (opcional no enunciado, mas util para o grupo)
# ----------------------------------------------------------------------
def carregar_csv(lista, caminho=ARQUIVO_CSV):
    """Retorna (carregados, ignorados). Linhas invalidas ou ids duplicados sao ignorados."""
    carregados = ignorados = 0
    if not os.path.exists(caminho):
        return 0, 0
    with open(caminho, newline="", encoding="utf-8") as f:
        for linha in csv.DictReader(f):
            try:
                reg = Orientacao(
                    id=int(linha["id"]),
                    categoria=linha["categoria"].strip(),
                    palavras_chave=linha["palavras_chave"].strip(),
                    titulo=linha["titulo"].strip(),
                    orientacao=linha["orientacao"].strip(),
                    fonte=linha["fonte"].strip(),
                    atualizado_em=linha["atualizado_em"].strip(),
                )
            except (KeyError, ValueError, AttributeError):
                ignorados += 1
                continue
            if not reg.titulo or lista.buscar_por_id(reg.id) is not None:
                ignorados += 1
                continue
            lista.inserir_fim(reg)
            carregados += 1
    return carregados, ignorados


def salvar_csv(lista, caminho=ARQUIVO_CSV):
    with open(caminho, "w", newline="", encoding="utf-8") as f:
        escritor = csv.DictWriter(f, fieldnames=CAMPOS)
        escritor.writeheader()
        for reg in lista:
            escritor.writerow({c: getattr(reg, c) for c in CAMPOS})


# ----------------------------------------------------------------------
# Validacao
# ----------------------------------------------------------------------
PADROES_DADOS_PESSOAIS = [
    re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b"),            # CPF
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"),                    # e-mail(Assistência de IA)
]
# Telefones nao sao bloqueados: orientacoes publicas citam telefones oficiais.


def contem_dado_pessoal(texto):
    return any(p.search(texto) for p in PADROES_DADOS_PESSOAIS)


def ler_inteiro(mensagem, minimo=1):
    while True:
        entrada = input(mensagem).strip()
        try:
            valor = int(entrada)
        except ValueError:
            print("  Entrada invalida: digite apenas numeros inteiros.")
            continue
        if valor < minimo:
            print(f"  O numero deve ser maior ou igual a {minimo}.")
            continue
        return valor


def ler_texto(mensagem, obrigatorio=True, atual=None):
    while True:
        entrada = input(mensagem).strip()
        if not entrada and atual is not None:
            return atual
        if obrigatorio and not entrada:
            print("  Campo obrigatorio: nao pode ficar vazio.")
            continue
        if contem_dado_pessoal(entrada):
            print("  Atencao: parece haver CPF ou e-mail. "
                  "Nao cadastre dados pessoais.")
            continue
        return entrada


# ----------------------------------------------------------------------
# Interface (menu)
# ----------------------------------------------------------------------
def mostrar(reg, resumido=False):
    if resumido:
        print(f"  [{reg.id:>3}] {reg.titulo}  ({reg.categoria})")
        return
    print("\n" + "-" * 62)
    print(f"ASSUNTO: {reg.titulo}")
    print(f"Tema: {reg.categoria}")
    print("\nO QUE VOCE PODE FAZER:")
    print(f"{reg.orientacao}")
    print(f"\nFonte da informacao: {reg.fonte}")
    print(f"Ultima atualizacao: {reg.atualizado_em}")
    print("-" * 62)


def listar(lista, resumido=True):
    if lista.esta_vazia():
        print("  Ainda nao ha orientacoes cadastradas.")
        return
    for reg in lista:
        mostrar(reg, resumido)
    print(f"\nTotal de orientacoes: {len(lista)}")


def consultar_por_assunto(lista):
    print("\n-- Sobre qual assunto voce precisa de ajuda? --")
    categorias = list(lista.contar_por_categoria().keys())
    if not categorias:
        print("Ainda nao ha assuntos cadastrados.")
        return
    for numero, categoria in enumerate(categorias, start=1):
        print(f"{numero}) {categoria}")
    print("0) Voltar")
    opcao = ler_inteiro("Digite o numero do assunto: ", minimo=0)
    if opcao == 0:
        return
    if opcao > len(categorias):
        print("Essa opcao nao existe. Tente novamente.")
        return
    categoria_escolhida = categorias[opcao - 1]
    achados = lista.pesquisar(categoria_escolhida, campo="categoria")
    print(f"\nOrientacoes sobre {categoria_escolhida}:")
    listar(achados, resumido=False)


def procurar_orientacao(lista):
    print("\n-- Encontrar uma orientacao --")
    print("Digite uma palavra sobre o que voce procura.")
    print("Exemplos: Pix, aposentadoria, vacina ou mensagem.")
    texto = ler_texto("O que voce procura? ")
    achados = lista.pesquisar(texto)
    if achados.esta_vazia():
        print("\nNao encontramos uma orientacao com essa palavra.")
        print("Tente outra palavra ou escolha um assunto no menu inicial.")
    else:
        print("\nEncontramos estas orientacoes:")
        listar(achados, resumido=False)


def cadastrar(lista):
    print("\n-- Cadastrar nova orientacao (equipe) --")
    sugestao = lista.proximo_id()
    while True:
        id_ = ler_inteiro(f"ID (sugestao {sugestao}): ")
        if lista.buscar_por_id(id_) is not None:
            print("  Esse ID ja existe. Escolha outro.")
        else:
            break
    reg = Orientacao(
        id=id_,
        categoria=ler_texto("Categoria: "),
        palavras_chave=ler_texto("Palavras-chave (separadas por ;): "),
        titulo=ler_texto("Titulo: "),
        orientacao=ler_texto("Orientacao: "),
        fonte=ler_texto("Fonte (ex.: gov.br): "),
        atualizado_em=date.today().strftime("%Y-%m"),
    )
    lista.inserir_fim(reg)
    salvar_csv(lista)
    print("  Orientacao cadastrada.")


def consultar(lista):
    print("\n-- Consultar registro da equipe por ID --")
    if lista.esta_vazia():
        print("  A lista esta vazia.")
        return
    reg = lista.buscar_por_id(ler_inteiro("ID: "))
    if reg is None:
        print("  Nenhum registro encontrado com esse ID.")
    else:
        mostrar(reg)


def pesquisar(lista):
    procurar_orientacao(lista)


def atualizar(lista):
    print("\n-- Atualizar orientacao (equipe) --")
    reg = lista.buscar_por_id(ler_inteiro("ID do registro: "))
    if reg is None:
        print("  Registro inexistente.")
        return
    print("  (Pressione Enter para manter o valor atual)")
    lista.atualizar(
        reg.id,
        categoria=ler_texto(f"Categoria [{reg.categoria}]: ", atual=reg.categoria),
        palavras_chave=ler_texto(f"Palavras-chave [{reg.palavras_chave}]: ", atual=reg.palavras_chave),
        titulo=ler_texto(f"Titulo [{reg.titulo}]: ", atual=reg.titulo),
        orientacao=ler_texto(f"Orientacao [{reg.orientacao[:40]}...]: ", atual=reg.orientacao),
        fonte=ler_texto(f"Fonte [{reg.fonte}]: ", atual=reg.fonte),
        atualizado_em=date.today().strftime("%Y-%m"),
    )
    salvar_csv(lista)
    print("  Orientacao atualizada.")


def excluir(lista):
    print("\n-- Excluir orientacao (equipe) --")
    reg = lista.buscar_por_id(ler_inteiro("ID do registro: "))
    if reg is None:
        print("  Registro inexistente.")
        return
    mostrar(reg, resumido=True)
    if input("  Confirma a exclusao? (s/n): ").strip().lower() == "s":
        lista.remover_por_id(reg.id)
        salvar_csv(lista)
        print("  Orientacao excluida.")
    else:
        print("  Exclusao cancelada.")


def ordenar(lista):
    print("\n-- Organizar orientacoes (Merge Sort) --")
    if lista.esta_vazia():
        print("  A lista esta vazia.")
        return
    print("  1) Numero   2) Titulo   3) Assunto")
    op = ler_inteiro("Escolha como organizar: ")
    chaves = {1: lambda r: r.id,
              2: lambda r: normalizar(r.titulo),
              3: lambda r: normalizar(r.categoria)}
    if op not in chaves:
        print("  Opcao inexistente.")
        return
    desc = input("  Ordem inversa? (s/n): ").strip().lower() == "s"
    lista.ordenar(chaves[op], reverso=desc)
    listar(lista)


def analise(lista):
    print("\n-- Resumo das orientacoes (equipe) --")
    if lista.esta_vazia():
        print("  Sem dados para analisar (lista vazia).")
        return
    total = len(lista)
    print(f"  Total de orientacoes: {total}")
    for cat, qtd in lista.contar_por_categoria().items():
        print(f"  - {cat}: {qtd} ({qtd * 100 / total:.1f}%)")


def menu_equipe(lista):
    """Funcoes administrativas mantidas para demonstrar os requisitos de DSA."""
    acoes = {1: cadastrar, 2: consultar, 3: atualizar, 4: excluir,
             5: pesquisar, 6: ordenar, 7: analise}
    while True:
        print("\n===== OPCOES DE ORGANIZACAO (EQUIPE) =====")
        print("1) Cadastrar orientacao     2) Consultar registro por numero")
        print("3) Atualizar orientacao     4) Excluir orientacao")
        print("5) Pesquisar orientacao     6) Organizar orientacoes")
        print("7) Ver resumo               8) Listar todos os registros")
        print("9) Salvar alteracoes        0) Voltar ao inicio")
        op = ler_inteiro("Escolha: ", minimo=0)
        if op == 0:
            break
        elif op == 8:
            listar(lista)
        elif op == 9:
            salvar_csv(lista)
            print("  Alteracoes salvas.")
        elif op in acoes:
            acoes[op](lista)
        else:
            print("  Opcao inexistente. Escolha um numero do menu.")


def menu():
    lista = ListaEncadeada()
    carregados, ignorados = carregar_csv(lista)
    print("\n============================================")
    print("             CITIZEN ASSIST AI")
    print("       Orientacoes simples para o dia a dia")
    print("============================================")
    print("Bem-vindo(a)! Vamos encontrar uma informacao?")
    if ignorados:
        print(f"Aviso: {ignorados} registro(s) nao puderam ser carregados.")
    print("Este e um prototipo academico. Nao substitui os canais oficiais.")

    while True:
        print("\nO QUE VOCE PRECISA?")
        print("1) Quero ajuda com um assunto")
        print("2) Procurar uma orientacao por palavra")
        print("3) Ver todas as orientacoes")
        print("4) Opcoes de organizacao (equipe do projeto)")
        print("0) Sair")
        op = ler_inteiro("Digite o numero: ", minimo=0)
        if op == 0:
            print("Obrigado por usar o Citizen Assist AI. Ate logo!")
            break
        elif op == 1:
            consultar_por_assunto(lista)
        elif op == 2:
            procurar_orientacao(lista)
        elif op == 3:
            listar(lista, resumido=False)
        elif op == 4:
            menu_equipe(lista)
        else:
            print("Essa opcao nao existe. Escolha um numero do menu.")


if __name__ == "__main__":
    menu()
