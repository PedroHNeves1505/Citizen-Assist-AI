"""
Evidencias de teste - Gerenciador de Orientacoes.
Execucao: python testes.py
Cada teste imprime: descricao | esperado | observado | OK/FALHOU
"""

import os
import tempfile

import builtins
import contextlib
import io

from gerenciador_orientacoes import (ListaEncadeada, Orientacao, normalizar,
                                     contem_dado_pessoal, carregar_csv, salvar_csv,
                                     ler_inteiro, ler_texto)

resultados = []


def teste(descricao, esperado, observado):
    ok = esperado == observado
    resultados.append(ok)
    print(f"[{'OK' if ok else 'FALHOU'}] {descricao}\n      esperado={esperado!r} observado={observado!r}")


def reg(id_, titulo="T", cat="Cat"):
    return Orientacao(id_, cat, "k", titulo, "texto", "fonte", "2026-11")


def ids(lista):
    return [r.id for r in lista]


print("=== LISTA VAZIA ===")
v = ListaEncadeada()
teste("Lista nova esta vazia", True, v.esta_vazia())
teste("Buscar ID em lista vazia", None, v.buscar_por_id(1))
teste("Remover de lista vazia", False, v.remover_por_id(1))
teste("Pesquisar em lista vazia", 0, len(v.pesquisar("golpe")))
v.ordenar(lambda r: r.id)
teste("Ordenar lista vazia nao quebra", 0, len(v))
teste("Contagem por categoria vazia", {}, v.contar_por_categoria())

print("\n=== INSERCAO E PERCURSO ===")
l = ListaEncadeada()
l.inserir_fim(reg(2, "Beta", "B"))
l.inserir_fim(reg(3, "alfa", "A"))
l.inserir_inicio(reg(1, "Gama", "A"))
teste("Ordem apos inserir inicio/fim", [1, 2, 3], ids(l))
teste("Tamanho", 3, len(l))

print("\n=== BUSCA ===")
teste("Buscar ID existente", "Beta", l.buscar_por_id(2).titulo)
teste("Buscar ID inexistente", None, l.buscar_por_id(99))
teste("Pesquisa ignora acento/maiuscula", [3], ids(l.pesquisar("ALFA", "titulo")))
teste("Pesquisa por categoria", [1, 3], ids(l.pesquisar("a", "categoria")))
teste("Pesquisa sem resultado", 0, len(l.pesquisar("xyzxyz")))
teste("Pesquisa com texto vazio", 0, len(l.pesquisar("   ")))

print("\n=== ORDENACAO (Merge Sort) ===")
l.ordenar(lambda r: normalizar(r.titulo))
teste("Ordenar por titulo (alfa, beta, gama)", [3, 2, 1], ids(l))
l.ordenar(lambda r: r.id, reverso=True)
teste("Ordenar por ID decrescente", [3, 2, 1], ids(l))
l.ordenar(lambda r: r.id)
teste("Ordenar por ID crescente", [1, 2, 3], ids(l))
l.inserir_fim(reg(4))
teste("Fim correto apos ordenar (insercao no fim)", [1, 2, 3, 4], ids(l))
um = ListaEncadeada(); um.inserir_fim(reg(7)); um.ordenar(lambda r: r.id)
teste("Ordenar lista com 1 elemento", [7], ids(um))
grande = ListaEncadeada()
for n in [9, 3, 7, 1, 8, 2, 6, 5, 4, 10, 0]:
    grande.inserir_fim(reg(n))
grande.ordenar(lambda r: r.id)
teste("Ordenar 11 elementos desordenados", list(range(11)), ids(grande))

print("\n=== ATUALIZACAO ===")
teste("Atualizar existente", True, l.atualizar(2, titulo="Novo"))
teste("Titulo atualizado", "Novo", l.buscar_por_id(2).titulo)
teste("Atualizar inexistente", False, l.atualizar(99, titulo="X"))
l.atualizar(2, id=500)
teste("ID nao pode ser alterado", 2, l.buscar_por_id(2).id)

print("\n=== REMOCAO ===")
teste("Remover do meio", True, l.remover_por_id(2))
teste("Lista apos remover meio", [1, 3, 4], ids(l))
teste("Remover o primeiro", True, l.remover_por_id(1))
teste("Remover o ultimo", True, l.remover_por_id(4))
teste("Lista apos remover extremos", [3], ids(l))
l.inserir_fim(reg(5))
teste("Inserir apos remover o ultimo (fim consistente)", [3, 5], ids(l))
teste("Remover inexistente", False, l.remover_por_id(42))
l.remover_por_id(3); l.remover_por_id(5)
teste("Remover tudo deixa lista vazia", (True, 0), (l.esta_vazia(), len(l)))

print("\n=== ANALISE ===")
a = ListaEncadeada()
for i, c in enumerate(["X", "Y", "X", "X"], start=1):
    a.inserir_fim(reg(i, cat=c))
teste("Contagem por categoria", {"X": 3, "Y": 1}, a.contar_por_categoria())
teste("Proximo ID", 5, a.proximo_id())

print("\n=== VALIDACAO ===")
teste("Detecta CPF", True, contem_dado_pessoal("meu cpf 123.456.789-09"))
teste("Detecta e-mail", True, contem_dado_pessoal("joao@email.com"))
teste("Telefone oficial nao e bloqueado", False, contem_dado_pessoal("Ligue (61) 3315-5000"))
teste("Texto comum passa", False, contem_dado_pessoal("Ligue para o numero 135"))


def simular(respostas, funcao, *args, **kwargs):
    """Executa 'funcao' com input() simulado. Retorna (resultado, saida_na_tela)."""
    fila = iter(respostas)
    original = builtins.input
    builtins.input = lambda _="": next(fila)
    saida = io.StringIO()
    try:
        with contextlib.redirect_stdout(saida):
            resultado = funcao(*args, **kwargs)
    finally:
        builtins.input = original
    return resultado, saida.getvalue()


print("\n=== ENTRADAS INVALIDAS (digitacao simulada) ===")
r, tela = simular(["abc", "", "-5", "7"], ler_inteiro, "N: ")
teste("Inteiro: 'abc', vazio e -5 rejeitados, aceita 7", 7, r)
teste("Inteiro: mensagem de entrada invalida exibida", True, "invalida" in tela)
r, tela = simular(["", "   ", "Pix seguro"], ler_texto, "T: ")
teste("Texto: vazio e so espacos rejeitados", "Pix seguro", r)
teste("Texto: mensagem de campo obrigatorio exibida", True, "obrigatorio" in tela)
r, tela = simular(["cpf 123.456.789-09", "ok"], ler_texto, "T: ")
teste("Texto: CPF rejeitado, aceita o seguinte", "ok", r)
r, _ = simular(["joao@email.com", "ok2"], ler_texto, "T: ")
teste("Texto: e-mail rejeitado", "ok2", r)
r, _ = simular([""], ler_texto, "T: ", atual="antigo")
teste("Atualizacao: Enter mantem valor atual", "antigo", r)
r, _ = simular(["0"], ler_inteiro, "Op: ", minimo=0)
teste("Inteiro: zero aceito quando minimo=0", 0, r)

print("\n=== CSV ===")
b = ListaEncadeada()
carregados, ignorados = carregar_csv(b)
teste("Carrega base inicial (12 registros)", (12, 0), (carregados, ignorados))
caminho = os.path.join(tempfile.gettempdir(), "teste_orientacoes.csv")
salvar_csv(b, caminho)
c = ListaEncadeada()
teste("Salvar e recarregar preserva dados", (12, 0), carregar_csv(c, caminho))
teste("Arquivo inexistente", (0, 0), carregar_csv(ListaEncadeada(), "nao_existe.csv"))
with open(caminho, "w", encoding="utf-8") as f:
    f.write("id,categoria,palavras_chave,titulo,orientacao,fonte,atualizado_em\n")
    f.write("1,A,k,T1,o,f,2026-11\n")
    f.write("1,A,k,Duplicado,o,f,2026-11\n")
    f.write("abc,A,k,IdInvalido,o,f,2026-11\n")
d = ListaEncadeada()
teste("Ignora ID duplicado e ID invalido", (1, 2), carregar_csv(d, caminho))
os.remove(caminho)

print(f"\nRESULTADO: {sum(resultados)}/{len(resultados)} testes passaram.")
